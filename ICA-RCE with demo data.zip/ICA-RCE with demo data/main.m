%run the GUI controller
con = Controller();

%after closing the GUI window, you should delete the controller object 
%using the following commnad:
%
%clear con


