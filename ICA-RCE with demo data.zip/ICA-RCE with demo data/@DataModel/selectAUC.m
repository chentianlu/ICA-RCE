function selectAUC(obj, selectedDCs, selectdCFs)
%%
%Area values under ROC of decomposed ICs instructed by the confounding factor.
%To be displayed as bar plot (x axis is IC index, y axis is the AUC values, decending order) 
%
%INPUTS
%selectedDCs: selected decomposed components, e.g. 1:3
%selectdCFs: selected confounding factors, e.g. 1:2
%
%OUTPUTS
%auc: a structure with 3 fields as follows:
%auc.av: value of each X vector instructed by each vector in Y
%auc.X: component numbers of decomposed components
%auc.Y: component numbers of confounding factors
%
%TECHNICAL DETAILS
%[X,Y, Thres, AUC(i,j)] = perfcurve(CF(:,i),T(:,j), POSITIVECLASS);
%Compute Receiver Operating Characteristic (ROC) curve for classifier output.
%[X,Y] = perfcurve(LABELS,SCORES,POSCLASS) computes a ROC curve for a
%vector of classifier predictions SCORES given true class labels, LABELS.
%SCORES is a numeric vector of scores returned by a classifier for some data. 
%The returned values X and Y are coordinates for the performance curve and
%can be visualized  with PLOT(X,Y). X is FP, Y is TP.
%%
%full set of decomposed components and confounding factors
decomposedComponents = obj.T; %obj.T;
confoundingFactors = obj.F;

%validate input value for selectedRCs
maxDCs = size(decomposedComponents,2);
selectedDCs = selectedDCs(find(selectedDCs<=maxDCs)); %make use of user selection, but only up to maxICs
%same for selectdCFs
maxCFs = size(confoundingFactors,2);
selectdCFs = selectdCFs(find(selectdCFs<=maxCFs)); %make use of user selection, but only up to maxICs

%make use of selected components only
decomposedComponents = decomposedComponents(:,selectedDCs);
confoundingFactors = confoundingFactors(:,selectdCFs);
%%
%test if the confounding factors are acceptable (limited to 2 groups
%per confounding factor)
dimY = size(confoundingFactors,2);
acceptableSelectdCFs = true(1, dimY); %at first, assume all confounding factors are acceptable
for i=1:dimY
    groups = unique(confoundingFactors(:,i));
    if (numel(unique(groups)) ~= 2)
        acceptableSelectdCFs(i)=false; %reject confounding factor that does not have 2 and only 2 groups
    end
end

%readjust classication variables to those that are acceptable
selectdCFs = selectdCFs(acceptableSelectdCFs);
confoundingFactors = confoundingFactors(:,acceptableSelectdCFs);
%%
dimX = size(decomposedComponents,2);
dimY = size(confoundingFactors,2);
av = zeros(dimY,dimX);
%%
%Area values under ROC of decomposed ICs 
%(bar plot, x axis is IC index and y axis is the AUC values, decending order) 
%instructed by the confounding factor.  
for i=1:dimY %i is the index of a confounding factor
    for j = 1:dimX %j is the index of a decomposed component
        av(i,j)=rocroc1(decomposedComponents(:,j),confoundingFactors(:,i));
    end
end
%%
%store the outputs
obj.aSelectAUC.av = av;
obj.aSelectAUC.X = selectedDCs;
obj.aSelectAUC.Y = selectdCFs;

end

%%
%private function
function [area varargout]=rocroc1(score,y)
%INPUTS
%score: a vector of decomposed component values
%y: a vector of true grouping values that is paired with the score vector
%OUTPUTS
%area: a vector of auc values that is paired with the roct vector 
%roct: two column vectors, sensitivity and 1-specificity
%%
%generate threshold vector (for use in predicting classes/groups)
minl = min(score);
maxl = max(score);
delta = (maxl-minl)/1000;
thresh = minl-delta*10 : delta : maxl+delta*10; %about 1000 threshold values (operating points)
%%
%storage vectors for about 1000 pairs of specificity and sensitivity values
spec = zeros(length(thresh),1); %stores count of TP for each threhold hold
sens = zeros(length(thresh),1); %stores count of total - FP
%%
%check groups in y (must contain only 2 classes, positive class and negative class) 
% test if the classification variables are acceptable (limited to 2 groups
% per classification variable)
groups = unique(y);
if (numel(groups) ~= 2)
    error('y must consists of 2 groups only');
else
    %convert y to binary vector (0 and 1 only)
    gp1 = y==groups(1);
    gp2 = y==groups(2);
    y(gp1)=0;
    y(gp2)=1;
end
%%
%hard-code negative class as 0 (group(2))
%hard-code positive class as 1 (groups(1))
for i =1:length(thresh)
    %cls will contain the predicted class/group for each score value at a particular threshold value
	cls = zeros(length(score),1); %initialized as not detected ('Negative')
    cls(score>thresh(i)) = 1; %set as detected if score value is above threshold value ('Positive')
    cntTruePositive = sum((y==1) & (cls==1)); %detected
    cntFalsePostive = sum((y==0) & (cls==1)); %false alarm
    cntTrueNegative = sum((y==0) & (cls==0)); 
    cntFalseNegative = sum((y==1) & (cls==0));  
    sens(i)= cntTruePositive/(cntTruePositive + cntFalseNegative); %Pd    
    spec(i) = 1 - cntFalsePostive/(cntFalsePostive + cntTrueNegative); %1-Pfa
end
%---------- compute the area under roc ------------
%    area=sum((y(i)+y(i+1))*(x(i+1)-x(i))/2)                   
%--------------------------------------------------
yplot = sens; %Pd
xplot = 1-spec; %Pfa
area=trapz(xplot, yplot);
if (area < 0)
    area = 1+area;
end
if (area < 0.5) 
    area = 1-area; 
end
roct=[xplot yplot];
varargout{1} = roct;
end


