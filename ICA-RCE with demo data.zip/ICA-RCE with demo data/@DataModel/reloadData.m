function reloadData(obj)
%reload raw data of input file into working variables Y, F, and M
obj.Y=obj.Y0;
obj.F=obj.F0;
obj.M=obj.M0;
end

