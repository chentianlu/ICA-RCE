function evaluateLogisticRegression(obj, selectdCVs) 
%%
%INPUTS
%selectedCCs: corrected components that are selected for processing, e.g. 1:3
%selectdCVs: classification variables that are selected for processing, e.g. 1:2
%
%OUTPUTS
%P, OR, and CIs of each variable with and without confounding factors as covariates 
%(crude and adjusted)
%box plot of P values with and without confounding factors as covariates.
%%    
%correctedComponents is the the set of predictors. It should be processed
%as one metabolite (crude) or one metabolite with all confounding factors (adjusted)
%full set of corrected components, classification variables, and confounding factors
correctedComponents = obj.Z; %should this be obj.M or obj.Z?
classificationVariables = obj.Y;
confoundingFactors = obj.F;

%validate the value of selectdCVs
maxVCs = size(classificationVariables,2);
selectdCVs = selectdCVs(find(selectdCVs<=maxVCs)); %make use of user selection, but only up to maxICs

%test if classification variables are binary type (2 and only 2 groups)
dimY = size(selectdCVs,2);
acceptableSelectdCVs = true(1, dimY);
for i=1:dimY
    vector = classificationVariables(:,selectdCVs(i));
    groups = unique(vector);
    if (numel(unique(groups)) ~= 2)
        acceptableSelectdCVs(i)=false;
    end
end

%readjust classication variables to those that are acceptable
selectdCVs = selectdCVs(acceptableSelectdCVs);
classificationVariables = classificationVariables(:,selectdCVs);
%%
%storage for outputs
dimX = size(correctedComponents,2);
dimY = size(classificationVariables,2);

pcrude = zeros(dimY,dimX);
padjusted = zeros(dimY,dimX);
%%
%Y is the vector for a classification variable vector
%training
for i=1:dimY %i is the index of a classification variable
    Y = classificationVariables(:,i);
    %convert to 1 and 0
    groups = unique(Y);
    Y(Y==groups(1))=0;
    Y(Y==groups(2))=1;
    for j=1:dimX %j is the index of a corrected variable
        X = correctedComponents(:,j);
        [OR1 pcrude1, CImin, CImax] = LogisticRegression(X,Y);
        ORcrude(i,j) = OR1;
        pcrude(i,j) = pcrude1;       
        CIcrude(i,j).min = CImin;
        CIcrude(i,j).max = CImax;
        %repeat prediction, this time using corrected matrix with all confounding factors
        Xadj = [X confoundingFactors];
        [OR1 pcrude1, CImin, CImax] = LogisticRegression(Xadj,Y);
        ORadjusted(i,j) = OR1;
        padjusted(i,j)=pcrude1; 
        CIadjusted(i,j).min = CImin;
        CIadjusted(i,j).max = CImax;
    end
end
%store the ouputs
obj.pEvaluateLogisticRegression.ORcrude = ORcrude;
obj.pEvaluateLogisticRegression.pcrude = pcrude;
obj.pEvaluateLogisticRegression.CIcrude = CIcrude;
obj.pEvaluateLogisticRegression.ORadjusted = ORadjusted;
obj.pEvaluateLogisticRegression.padjusted = padjusted;
obj.pEvaluateLogisticRegression.CIadjusted = CIadjusted;
obj.pEvaluateLogisticRegression.Y = selectdCVs;
end

function [OR pcrude CImin CImax] = LogisticRegression(X,Y)
    B = glmfit(X,Y,'binomial', 'link', 'logit'); %B=[b1; b2] and logit(p)=b1+b2*x
    %yfit is the proability of group membership, cut-off at 0.5
    yfit= glmval(B,X, 'logit');% when X consists of just metabolites, the OR is called crude OR. when X has a confounding factors, the OR is called adjusted OR.
    OR = exp(B(2)); 
    %Performs a chi-square goodness-of-fit test that the data in yfit are a 
    %random sample from a normal distribution. The result is H=0 if the 
    %null hypothesis (that yfit is a random sample from a normal distribution)
    %cannot be rejected at the 5% significance level, or H=1 if the null 
    %hypothesis can be rejected at the 5% level.
    %for H = chi2gof(yfit), yfit must have at least 40 cases, otherwise NaN will be returned 
    [H, pcrude] = chi2gof(yfit); % P value of OR: chi-square test of x and yfit
    %hard-code negative class as groups(1)
    %hard-code positive class as groups(2)
    groups = unique(Y);
    NEGATIVECLASS = groups(1);
    POSITIVECLASS = groups(2);
    %compare yfit with Y
    %cls will contain the predicted class for each case at 0.5 threshold
    cls = zeros(length(Y),1); %initialized as not detected ('Negative')
    cls(:) = groups(1); %set to negative class for all test cases
    cls(yfit>0.5) = groups(2); %set as detected if yfit value is above threshold value of 0.5 ('Positive')
    A = sum((Y==POSITIVECLASS) & (cls==POSITIVECLASS)); %A, cntTruePositive
    C = sum((Y==NEGATIVECLASS) & (cls==POSITIVECLASS)); %C, cntFalsePostive
    D = sum((Y==NEGATIVECLASS) & (cls==NEGATIVECLASS)); %D, cntTrueNegative
    B = sum((Y==POSITIVECLASS) & (cls==NEGATIVECLASS)); %B, cntFalseNegative
    %95% CI of ln(OR) = ln(OR)�1.96(1/A + 1/B + 1/C + 1/D)^0.5  % ABCD are count values
    %s = 1.96(1/A + 1/B + 1/C + 1/D)0.5;
    interval = 1.96*(1/A + 1/B + 1/C + 1/D)^0.5;
    CImin = exp(1)^(log(OR) - interval);
    CImax = exp(1)^(log(OR) + interval);
end