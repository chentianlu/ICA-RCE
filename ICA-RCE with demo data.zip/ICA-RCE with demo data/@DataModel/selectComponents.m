function comps = selectComponents(obj, top)
%OUTPUT
%comps - Indexes of selected ICs related to the confounding factor of interest. 
%options - Let user input threshold values (or rankings) for these criteria with the 
%help of the 2-4 bar plots. Default is the intersection of top 10 ICs by 
%every criterion. Final decision should be done by user.
compsMW = rankByMannWhitney(obj);
compsAnova = rankByAnova(obj);
compsCorrelation = rankByCorrelation(obj);
compsAUC = rankByAUC(obj);

comps = rankByIntersaction(compsMW, compsAnova, compsCorrelation, compsAUC);
%choose the top few components 
comps = comps(1:top);
end

%private
function comps = rankByMannWhitney(obj)
pv = obj.pSelectMannWhitney.pv;
selectedDCs = obj.pSelectMannWhitney.X;
selectdCFs = obj.pSelectMannWhitney.Y;

dimY = size(selectdCFs,2);
for i=1:1%KBH limited to first CF for now
    [p, index] = sort(pv(i,:),'ascend'); %choose smallest p-value          
end
comps = selectedDCs(index);
end

function comps = rankByAnova(obj)
pv = obj.pSelectAnova.pv;
selectedDCs = obj.pSelectAnova.X;
selectdCFs = obj.pSelectAnova.Y;

dimY = size(selectdCFs,2);
for i=1:1%KBH limited to first CF for now
    [p, index] = sort(pv(i,:),'ascend'); %choose smallest p-value          
end
comps = selectedDCs(index);
end

function comps = rankByCorrelation(obj)
rv = obj.rSelectCorrelation.rv;
selectedDCs = obj.rSelectCorrelation.X;
selectdCFs = obj.rSelectCorrelation.Y;

dimY = size(selectdCFs,2);
for i=1:1%KBH limited to first CF for now
    [r, index] = sort(abs(rv(i,:)),'descend'); %choose largest correlation (by absolute values)         
end
comps = selectedDCs(index);

end

function comps = rankByAUC(obj)
av = obj.aSelectAUC.av;
selectedDCs = obj.aSelectAUC.X;
selectdCFs = obj.aSelectAUC.Y;

dimY = size(selectdCFs,2);
for i=1:1%KBH limited to first CF for now
    [rv, index] = sort(av(i,:),'descend'); %choose largest AUC          
end
comps = selectedDCs(index);

end

function comps = rankByIntersaction(compsMW, compsAnova, compsCorrelation, compsAUC)
%ICs with large AUC, large correlation, and small P values should be chosen.
comps = intersect(compsMW, compsAnova,'stable');
comps = intersect(comps, compsCorrelation,'stable');
comps = intersect(comps, compsAUC,'stable');
end