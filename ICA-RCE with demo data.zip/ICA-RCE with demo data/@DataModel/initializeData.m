function initializeData(obj)
    obj.timeCPU.PCOSC=[];
    obj.timeCPU.DOSC=[];
    obj.timeCPU.ICA=[];
    obj.timeCPU.RAW=[];
end

