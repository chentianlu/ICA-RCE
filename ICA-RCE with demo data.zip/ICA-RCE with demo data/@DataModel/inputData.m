function inputData(obj, fname, path)
%%[M Y F] = inputdata(fname, path)
%INPUTS
%fname: file name with file extension
%path: full path of folder with ending slash
%
%STORED DATA
%obj.M0: metabolite concentrations
%obj.Y0: classification variables
%obj.F0: confounding factors
%obj.ng: number of categories (classification variables)
%obj.nc: number of confounding factors
%obj.nm: number of metabolites
%obj.file: file name with file extension, e.g. xxx.xls
%obj.path: absolute path of the folder containing the path, including the ending \
%
%REQUIREMENTS
%Input excel or csv files 
%50 samples*600 variables (concentrations of metabolites, confounding 
%factors, classification variable), 600 samples *50 variables, 
%200 samples*200 variables,... with matched and mis-matched gender, with
%significantly different (P<0.05) age and BMI, with different races...
%% 
obj.file = fname;
obj.path = path;

ext=fname(end-2:end); %extract file extension (last 3 characters)
if ~strcmpi(ext,'csv') && ~strcmpi(ext,'xls') %check for 'csv' and '.xls'
    tmp=fname(end-3:end); %check for '.xlsx' (last 4 characters)
    if ~strcmpi(tmp,'xlsx')
        error('Incorrect file extension. Must be ''csv'', ''xls'' or ''xlsx'' ');
    else
        ext = tmp;
    end
end

%initialize the matrices that are to be stored
obj.M0=[];
obj.F0=[];
obj.Y0=[];

switch ext
    case 'csv'
        fid = fopen([path fname],'r');
        %get the first line so as to determine the number of columns in file
        line = fgetl(fid);
        tmp = textscan(line, '%s', 'delimiter', ','); %scan the header line
        headers = [tmp{1}]; % vector of header strings 
        ncols=numel(headers); % total number of columns in dataset
        %case insenstive comparison of 1st character of all strings in vector
        obj.ng = sum(strncmpi(headers,'g',1)); %number of groups (i.e. classification variables)
        obj.nc = sum(strncmpi(headers,'c',1)); %number of confounding factors
        obj.nm = sum(strncmpi(headers,'m',1)); %number of metabolites
        %now scan the file, assuming all data are floating point numbers
        format = repmat('%f', [1, ncols]); %construct format that fits the no. of columns
        %read the rest of the file in one go; ignore actual header row (2nd line in file)
        D = textscan(fid,format,'delimiter', ',','HeaderLines',1); 
        fclose(fid);
        %D is a row array consisting of ncols columns of cell arrays 
        obj.Y0 = cell2mat(D(1:obj.ng)); %classification variables
        obj.F0 = cell2mat(D((obj.ng+1):(obj.ng+obj.nc))); %confounding factors
        obj.M0 = cell2mat(D((obj.ng+obj.nc+1):(obj.ng+obj.nc+obj.nm))); %concentrations of metabolites           
    case {'xls','xlsx'}
        [data,headers] = xlsread([path fname]);
        %assume the data types (group, confounding factor, and
        %metabolite) are in the first row headers; ignore 2nd row headers
        obj.ng = sum(strncmpi(headers(1,:),'g',1));
        obj.nc = sum(strncmpi(headers(1,:),'c',1));
        obj.nm = sum(strncmpi(headers(1,:),'m',1));
        %extract relevant columns
        obj.Y0 = data(:,1:obj.ng); %classification variables
        obj.F0 = data(:,(obj.ng+1):(obj.ng+obj.nc)); %confounding factors
        obj.M0 = data(:,(obj.ng+obj.nc+1):(obj.ng+obj.nc+obj.nm)); %concentrations of metabolites    
end
obj.reloadData();
end
