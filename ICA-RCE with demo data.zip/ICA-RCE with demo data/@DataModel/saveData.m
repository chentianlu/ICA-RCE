function bool = saveData(obj)
    if isequal(obj.file, 0) || isempty(obj.file)
        bool = false;
    else        
        %since Matlab 'save' command cannot recognise 'obj.Y' as variable name...
        Y = obj.Y; F = obj.F; M = obj.M;
        Z = obj.Z; W = obj.W; P = obj.P; T = obj.T; 
        ops = obj.transformoptions;      
        ng = obj.ng; nc = obj.nc; nm = obj.nm;
        timePCOSC = obj.timePCOSC; timeDOSC = obj.timeDOSC; timeICA = obj.timeDOSC; timeEMD = obj.timeEMD;
        evaluatePLST2D = obj.evaluatePLST2D;
        evaluatePLSR2X = obj.evaluatePLSR2X;
        evaluatePLSR2Y = obj.evaluatePLSR2Y;
        evaluatePLSQ2 = obj.evaluatePLSQ2;
        evaluatePLSerr = obj.evaluatePLSerr;
        T2D = obj.T2D;
        evaluatePCAT2D = obj.evaluatePCAT2D;
        evaluatePCAR2X = obj.evaluatePCAR2X;
        pEvaluateMannWhitney = obj.pEvaluateMannWhitney;
        pEvaluateAnova = obj.pEvaluateAnova;
        rEvaluateCorrelation = obj.rEvaluateCorrelation;
        pEvaluateLogisticRegression = obj.pEvaluateLogisticRegression;        
        pSelectMannWhitney = obj.pSelectMannWhitney;
        pSelectAnova = obj.pSelectAnova;
        rSelectCorrelation = obj.rSelectCorrelation;
        aSelectAUC = obj.aSelectAUC;

        %save as '.mat' file
        %replace file name of opened data file extention with '.mat'
        mat=regexprep(obj.file,'(.csv|.xls|.xlsx)$','.mat'); 
        save ([obj.path mat],'Y','F','M','Z','W','P','T','ops',...
            'ng','nc','nm','timePCOSC','timeDOSC','timeICA','timeEMD',...
            'evaluatePLST2D','evaluatePLSR2X','evaluatePLSR2Y',...
            'evaluatePLSQ2','evaluatePLSerr','T2D','evaluatePCAT2D',...
            'evaluatePCAR2X','pEvaluateMannWhitney','pEvaluateAnova',...
            'rEvaluateCorrelation','pEvaluateLogisticRegression',...
            'pSelectMannWhitney','pSelectAnova','rSelectCorrelation',...
            'aSelectAUC'...
            ); 
        bool = true;
    end
end