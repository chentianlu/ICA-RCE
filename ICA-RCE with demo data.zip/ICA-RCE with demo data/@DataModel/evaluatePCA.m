function evaluatePCA(obj, selectedCVs)
%validate the input value of selectedCVs
maxCVs = size(obj.Y,2);
selectedCVs = selectedCVs(find(selectedCVs<=maxCVs)); %make use of user selection, but only up to maxICs

%group by the selected classification variables Y when displaying score plot
classificationVariables = obj.Y(:,selectedCVs);
dimY = size(classificationVariables,2);

%PCA
X = obj.Z; 
X = zscore(X);
%%
[XS R2X]=PCA2PC(X);
%split XS into groups according to classificationVariables     
for i=1:dimY
    grouping = classificationVariables(:,i);
    groups = unique(grouping);       
    for k=1:numel(groups)
        group(k).values = XS(grouping==groups(k),:);
    end
    T(i).group = group;  %access each group by T(3).group(5).values
end

%store results into Model object
obj.evaluatePCAT2D = T;
obj.evaluatePCAR2X = R2X;

end

function [XS R2X] = PCA2PC(X)
    [P,T,latent]=princomp(X,'econ');
    R2X = sum(latent(1:2))/sum(latent);
    XS = T(:,1:2); %the first two principal components
end