function transformData(obj,options)
    %store user-selected choices into the Model object so that they can be
    %saved into a .mat file later
    obj.transformoptions.normalizationmode = options.normalizationmode;
    obj.transformoptions.newmax = options.newmax;
    obj.transformoptions.newmin = options.newmin;
    obj.transformoptions.logselected = options.logselected;
    obj.transformoptions.logbase = options.logbase;
    obj.transformoptions.logconstant = options.logconstant;

    %perform normalization
    obj.M = transforming(obj.M, options.normalizationmode, options.newmax, options.newmin);
    %perform log transformation
    if (options.logselected == 1)
        obj.M = transforming(obj.M, 'Log', options.logbase, options.logconstant);
    end
end

%%private functions
function X = transforming(X, mode, varargin)
%%X = transforming(X, mode, varargin)
%INPUTS
%X: an n by p matrix, with n cases and p variables
%mode: 'normalize by variable', 'normalize by sample', 'log',
%       'standardize', 'mean-centered'
%varargin for 'normalize by variable': newmax, newmin (default: 1 and 0)
%varargin for 'normalize by sample': newmax, newmin (default: 1 and 0)
%varargin for 'log': base, regularizing constant (default: 2 and 0.01)
%
%OUTPUT
%X: a matrix with the same size as the input
%
%REQUIREMENTS
%Data could be normalized (default to [0,1]) by sample or variable and/or 
%log transformed (default base is 2 and default constant term is 0.01*min
%of data) as user specified before preprocessing. 

switch mode
    %no transformation needed
    case 'None'
        %do nothing
        %the input X remains unchanged and becomes the output
    %normalize to newmax to newmin
    case 'Normalize by Variable' % %Xchanged = (X - Xmin)/(Xmax-Xmin)*(newmax-newmin) + newmin
        if length(varargin) < 1, newmax=1;else newmax = varargin{1}; end
        if length(varargin) < 2, newmin=0;else newmin = varargin{2}; end
        X = normalize(X, newmax, newmin);
    %KBH: wouldn't this disturb the linear relationship between the variables?
    case 'Normalize by Sample'
        if length(varargin) < 1, newmax=1;else newmax = varargin{1}; end
        if length(varargin) < 2, newmin=0;else newmin = varargin{2}; end        
        X = normalize(X', newmax, newmin); %transpose X as the input
        X = X'; %transpose back

    %Xchanged = log(X + a)
    %Log transformation is used to make the variable's distribution more
    %normal when it is negatively skewed 
    %To handle negative and zero data values, add a constant value to the 
    %data such that min(X+a) = a small positive constant (like 0.01)
    case 'Log'
        if length(varargin) < 1, base=2;else base = varargin{1}; end
        if length(varargin) < 2, constant=0.01;else constant = varargin{2}; end
        minv = min(min(X)); % minv is a scalar
        a = constant-minv;
        X = log(X+a)/log(base); % log(base) is a scalar 

    %Like log transation, sqrt transformation is also used to make the 
    %variable's distribution more normal when it is negatively skewed 
    case 'Sqrt'
        X = sqrt(X);  
    %Sqrt transformation is used to make the variable's distribution more
    %normal when it is positively skewed 
    case 'Exp'
        if length(varargin) < 1, pow=2;else pow = varargin{1}; end
        X = X.^pow; 
    %subtract column mean, then divide by column SD
    case 'Standardize'
        meanv = mean(X); %meanv is a row vector     
        stdv = diag(std(X)); %scale is a diagonal matrix 
        dimX = size(X,1); %no. of rows in X
        X = X - repmat(meanv, dimX, 1); %replicate mean values over multiple rows 
        X = X/stdv; % divide (i.e. matrix inverse) by std 
    case 'Mean-Centered'
        meanv = mean(X);
        dimX = size(X,1); %no. of rows in X
        X = X - ones(dimX,1)*meanv; %similar to: X = X - repmat(meanv, dimX, 1);
end
end

%%private function: X = normalize(X, b, a)
%X: a matrix
%b: the new max value (a scalar)
%a: the new min value (a scalar)
%formula: Xchanged = (X - Xmin)/(Xmax-Xmin)*(newmax-newmin) + newmin
function X = normalize(X, newmax, newmin)
    minv = min(X); % minv is a row vector
    rangev = max(X)-min(X);
    minv = repmat(minv, size(X, 1), 1); % repeat the row vector down the columns 
    rangev = repmat(rangev, size(X, 1), 1);
    X = ((X - minv)./rangev)*(newmax - newmin)+newmin;    
end