function selectCorrelation(obj, selectedDCs, selectdCFs) 
%INPUTS
%selectedDCs: selected decomposed components, e.g. 1:3
%selectdCFs: selected confounding factors, e.g. 1:2
%
%OUTPUTS
%r: a structure with 4 fields as follows:
%r.rv: a matrix containing the correlation coefficients of each X vector instructed by each vector in Y
%r.X: component numbers of decomposed components
%r.Y: component numbers of confounding factors
%r.stats: a struct containing mean, meadian, max and min of r values for confounding factors
%
%TECHNICAL DETAILS
%RHO = corr(X, Y)
%returns the pairwise correlation coefficient when X and Y are both column vectors
%'type','Spearman' will correlate ordinal data according to their ranking order
%%
%full set of decomposed components and confounding factors
decomposedComponents = obj.T;
confoundingFactors = obj.F;

%validate input value for selectedDCs
maxICs = size(decomposedComponents,2);
selectedDCs = selectedDCs(find(selectedDCs<=maxICs)); %make use of user selection, but only up to maxICs
%same for selectdCFs
maxICs = size(confoundingFactors,2);
selectdCFs = selectdCFs(find(selectdCFs<=maxICs)); %make use of user selection, but only up to maxICs

%make use of selected components only
decomposedComponents = decomposedComponents(:,selectedDCs);
confoundingFactors = confoundingFactors(:,selectdCFs);

dimX = size(decomposedComponents,2);
dimY = size(confoundingFactors,2);
rv = zeros(dimY,dimX);

%%
% confounding factor-decomposed component pair
for i=1:dimY %i is the index of the decomposed component
    for j=1:dimX %j is the index of a confounding factor
        rv(i,j) = corr(confoundingFactors(:,i), decomposedComponents(:,j), 'type', 'spearman');
    end
end
%%
%store r (a matrix) and its matching component numbers in rows and columns
%
obj.rSelectCorrelation.rv = rv;
obj.rSelectCorrelation.X = selectedDCs;
obj.rSelectCorrelation.Y = selectdCFs;
end