function reconstructData(obj, selectedRCs)
    selectedIC = obj.T(:,selectedRCs);
    selectedP = obj.P(:,selectedRCs);
    Z = obj.M - selectedIC*selectedP'; % Z is the corrected X after disregarding LVs
    obj.Z = Z;
end

