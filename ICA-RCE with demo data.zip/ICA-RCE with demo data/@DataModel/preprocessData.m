function preprocessData(obj, mode, numDCs)
%%
%preprocess(M, mode, numDCs)
%INPUTS
%mode: 'PC-OSC', 'DOSC', 'ICA', or 'RAW'
%numDCs:  number of decomposed components (default: 2)
%
%DATA TO USE
%obj.M: metabolite concentrations, each column in obj.M is a variable (I x J)
%obj.Y: classification variable, each column in obj.Y is a variable (I x G)
%
%STORED DATA
%obj.T: the orthogonal or independent components; no. of columns in T as specified by user (I x nocomp)
%obj.W: T = XW; the vector used to obtain the orthogonal or independent components (J x nocomp)
%obj.P: TP' is the estimation of X based on T; the matrix TP' has the same size as X   (J x nocomp)
%obj.Z: Z = X - T*P'; X is "deflated" wrt T; Z is the "corrected" X with less or no relationship with T (I x J)
%
%CALLED BY
%this function will be called by the Controller
%
%REQUIREMENTS
%Output datasets for all the preprocessing methods.
%For OSC based methods, let user specify the number of orthogonal components;
%the default is 2.

obj.preprocessmode = mode;
%clear output data before processing
obj.Z=[]; %corrected or "adjusted" matrix (Z = X - TP'); Z has same size as X
obj.W=[]; %T=XW(:,i)
obj.P=[]; %TP' has the same size as X
obj.T=[]; %orthogonal, independent, or "removed" components   

switch mode
    case 'PC-OSC' 
        tic
        %KBH: have not figured out how to implement PC-OSC. Below is 
        %a placeholder using PCA
        %mean-center the input data 
        meanv = mean(obj.M);
        dimX = size(obj.M,1); %no. of rows in X
        obj.M = obj.M - ones(dimX,1)*meanv; %similar to: X = X - repmat(meanv, dimX, 1);
        %generate the covaraince matrix
        sigma = obj.M'* obj.M / size(obj.M, 2); %sigma is the covariance matrix of X
        %the ouput S is required by the svd function, although it is not used subsequently
        [obj.W S] = svd(sigma); %W are eigenvectors (by columns)
        WP = obj.W(:,1:numDCs); %choose the eigenvectors that correspond to the largest few eigenvalues
        obj.T = obj.M*WP; %the first few principal components
        P = pinv(WP); %P is the remixing matrix; TP is a (remixed) estimate of X
        obj.P = P'; %to fit into the definition of P in DOSC
        obj.Z = obj.M - obj.T*obj.P'; %Z is expected to be close to 0 and random about 0
        %[x, y]= princomp(obj.M), where x is obj.P and y is obj.T
        %
        obj.timeCPU.PCOSC = toc;
    case 'DOSC' 
        tic
        %T: DOSC components (I x nocomp)
        %W: Weights to determine DOSC components (J x nocomp), T = X*W
        %P: Loadings to remove DOSC component from X (J x nocomp), estX=TP'
        %Z: DOSC corrected matrix X(I x J), Z = X - T*P'        
        [obj.Z,obj.W,obj.P,obj.T] = dosc(obj.M,obj.Y,numDCs,1E-03);
        obj.timeCPU.DOSC = toc;
    case 'ICA'         
        tic
        %input validation: check if numICs is permissible
        if (numDCs > min(size(obj.M)))
            numDCs = min(size(obj.M));
        end
        %X is the transpose of obj.M, since fastica expects data as row vectors       
        [icasig, A, W]=fastica(obj.M','numOfIC',numDCs,'verbose','off'); % icasig=W*X
        %transpose icasig, A, and W, since fastica considers a vector
        %as a row vector whereas we will consider a vector as a column
        %transpose(icasig)=transpose(W*X) becomes transpose(X)*transpose(W)
        obj.T = icasig'; %T contains the independent variables, equiv to DOSC components
        obj.W = W'; %after aforementioned transposes, T=X*W (W is unmixing matrix)
        P = A'; %A is the mixing matrix, TP is a (remixed) estimate of X
        %if numICs include all components, A = inv(W), otherwise A is not inv(W)
        obj.P = P'; %to fit into the definition of P in DOSC
        obj.Z = obj.M - obj.T*obj.P'; %Z is the corrected X after disregarding LVs
        %Z will be close to 0 and random about 0 if numICs include all the components
        obj.timeCPU.ICA = toc;
    case 'RAW'
        tic
        obj.T=obj.M; %decomposed components; it is initialized to M before any decomposition is done
        obj.P=eye(size(obj.T,2)); %initial weights that can be used to map T to M (i.e., T*P')
        obj.W=eye(size(obj.T,2)); %initial weights that can be used to map T to M (i.e., T*P')
        obj.Z=obj.M; %Z is the corrected matrix; it is initialized to M before any correction is done 
        obj.timeCPU.RAW = toc;
    otherwise
        obj.T=obj.M; %decomposed components; it is initialized to M before any decomposition is done
        obj.P=eye(size(obj.T,2)); %initial weights that can be used to map T to M (i.e., T*P')
        obj.W=eye(size(obj.T,2)); %initial weights that can be used to map T to M (i.e., T*P')
        obj.Z=obj.M; %Z is the corrected matrix; it is initialized to M before any correction is done 
end
end

