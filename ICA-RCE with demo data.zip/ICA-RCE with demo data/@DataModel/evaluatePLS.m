function evaluatePLS(obj, selectedCVs)
%%
%INPUTS
%selectedCVs: component numbers of classification variables in obj.Y
%
%STORED OUTPUTS
%XS, R2X, R2Y, Q2, 100 permuted R2X, R2Y and Q2
%
%TECHNICAL DETAILS
%plsregress(X,Y) uses the SIMPLS algorithm, first centering X and Y by 
%subtracting off column means to get centered variables X0 and Y0.
%However, it does not rescale the columns.       
%%
%validate the input value of selectedCVs
maxCVs = size(obj.Y,2);
selectedCVs = selectedCVs(find(selectedCVs<=maxCVs)); %make use of user selection, but only up to maxCVs
%make use of selected components only
classificationVariables = obj.Y(:,selectedCVs);
dimY = size(classificationVariables,2);
%input
X = obj.Z; %corrected M
X= zscore(X);
%%
Y=[];
T=[];
permute=[];
for i=1:dimY %i is the index of a vector in classificationVariables
    %Y is a classification variable
    Y = classificationVariables(:,i); 
    %change Y values to {0,1}
    groups = unique(Y);
    gp1 = Y==groups(1);
    gp2 = Y==groups(1);
    Y(gp1)=0;
    Y(gp2)=1;
    %%
    [XS r2x r2y q2 cyyr]= PLS1Y(X,Y,Y);
    R2X(i,1) = r2x;
    R2Y(i,1) = cyyr; R2Y(i,2) = r2y;
    Q2(i,1) = cyyr; Q2(i,2) = q2;
    %%
    %split XS into groups so as to display XS in groups     
    groups = unique(Y);
    group = [];
    for k=1:numel(groups)
        group(k).values = XS(Y==groups(k),:); 
    end
    T(i).group = group; %to access each group, use, for example, T(1).group(1).values

    %repeat 100 times tha same calculation for R2 and Q2
    ncases = size(X, 1);
    NUM_REPETITION = 100;
    for k=1:NUM_REPETITION
        %%
        randomindices = randperm(ncases);
        YR = Y(randomindices);
        [XS r2x r2y q2 cyyr]= PLS1Y(X,Y,YR);
        permute(i).R2Y(k,2) = r2y; %to be stored at the end of this function file
        permute(i).R2Y(k,1) = cyyr; %to be stored at the end of this function file
        permute(i).R2X(k) = r2x; %to be stored at the end of this function file
        permute(i).Q2(k,2) = q2;
        permute(i).Q2(k,1) = cyyr;      
    end %end, permute
end

obj.dEvaluatePLS.T=T;
obj.dEvaluatePLS.R2X=R2X;
obj.dEvaluatePLS.R2Y=R2Y;
obj.dEvaluatePLS.Q2=Q2;
obj.dEvaluatePLS.permute=permute;
obj.dEvaluatePLS.selectedCVs=selectedCVs;

end

%%private function
%X is the metabolites (can be either crude or corrected)
%Y is a single classification variable (for reference)
%YR is either Y or its randomized version (actually used)
function [XS R2X R2Y Q2 CYYR]= PLS1Y(X, Y, YR)
    %PLS
    [XL,YL,XS,YS,BETA,PCTVAR,MSE,stats] = plsregress(X,YR,2, 'cv',10); 
    R2X = sum(PCTVAR(1,:));
    R2Y = sum(PCTVAR(2,:));
    CYYR = corr(Y,YR);
    %Q2
    ncases = size(X, 1);
    CC=[];
    [CC,err,P,logp,coeff] = classify(XS,XS, YR,'diaglinear');
    CB=[];
    YB=[];
    CCV=[];
    for j=1:7
        CC1 = [];
        YC1 = [];
        [train, test] = crossvalind('HoldOut', ncases, 1/7); %6/7 for training, 1/7 for testing
        XSTrain = XS(train,:);
        YTrain = YR(train);
        XSTest = XS(test,:);
        YTest = YR(test);
        [CC1,err,P,logp,coeff] = classify(XSTest,XSTrain, YTrain,'diaglinear');
        CB = [CB; CC1]; %predicted classes of XSTest trained on XSTrain
        YB = [YB; YTest]; %actual classes of XSTest
        CCV = [CCV; CC(test)]; %predicted classes trained on XS
    end
    N = (CCV - YB)'*(CCV - YB); %SS residue
    D = (CCV-mean(CB))'*(CCV-mean(CB));
    Q2 = 1 - N/D;   
end
