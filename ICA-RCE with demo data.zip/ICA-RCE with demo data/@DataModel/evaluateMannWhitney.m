function evaluateMannWhitney(obj, selectedRCs, selectdCVs) 
%INPUTS
%selectedRCs: selected removed components, e.g. 1:3
%selectdCVs: selected classification variable, e.g. 1:2
%
%OUTPUTS
%p: a structure with 4 fields as follows:
%p.pv: value of each X vector instructed by each vector in Y
%p.X: component numbers of removed components
%p.Y: component numbers of classification variables
%p.stats: a struct containing mean, meadian, max and min of p values for classifcation variables
%
%TECHNICAL DETAILS
%P = ranksum(X,Y) 
%X and Y are two independent samples (yes, ranksum can only be used for
%2 groups and not for 3 or more groups)
%The two sets of data are assumed (null hypothesus) to come from continuous
%distributions that are identical except possibly for a location shift.  
    
%full set of removed components and classifcation variables
removedComponents = obj.T; %actual removed components to be selected fromt this full set later 
classificationVariables = obj.Y;

%validate input value for selectedRCs
maxRCs = size(removedComponents,2);
selectedRCs = selectedRCs(find(selectedRCs<=maxRCs)); %make use of user selection, but only up to maxICs
%same for selectdCVs
maxCVs = size(classificationVariables,2);
selectdCVs = selectdCVs(find(selectdCVs<=maxCVs)); %make use of user selection, but only up to maxICs

%make use of selected components only
removedComponents = removedComponents(:,selectedRCs);
%KBH classificationVariables = classificationVariables(:,selectdCVs);

%test if the classification variables are acceptable (must consist of 2
%and only 2 groups per classification variable)
dimY = size(selectdCVs,2);
acceptableSelectdCVs = true(1, dimY);
for i=1:dimY
    vector = classificationVariables(:,selectdCVs(i));
    groups = unique(vector);
    if (numel(unique(groups)) ~= 2)
        acceptableSelectdCVs(i)=false;
    end
end

%readjust classication variables to those that are acceptable
selectdCVs = selectdCVs(acceptableSelectdCVs);
classificationVariables = classificationVariables(:,selectdCVs);
dimX = size(removedComponents,2);
dimY = size(classificationVariables,2);
pv = zeros(dimY,dimX);
%%
%for i=1:dimY
%    grouping = classificationVariables(:,i);
    %KBH groups = unique(grouping);    
%    for j=1:dimX
%        data = removedComponents(:,j);
%        pv(i,j)= MannWhitney(data, grouping) 
%    end
%end

%Mann-Whitney
for i=1:dimY %i is the index of a confounding factor
    Y = classificationVariables(:,i);
    for j=1:dimX %j is the index of a decomposed component       
        X = removedComponents(:,j); %data is the vector containing the values of the decomposed component 
        pv(i,j) = MannWhitney(X, Y)
    end
end

%%
%statistics in column vector, one value for each instructing factor
meanp = mean(pv, 2); %average across the removed components
medianp = median(pv,2);
maxp = max(pv')';
minp = min(pv')';
obj.pEvaluateMannWhitney.pv = pv;
obj.pEvaluateMannWhitney.X = selectedRCs;
obj.pEvaluateMannWhitney.Y = selectdCVs;
obj.pEvaluateMannWhitney.stats.meanp = meanp;
obj.pEvaluateMannWhitney.stats.medianp = medianp; 
obj.pEvaluateMannWhitney.stats.maxp = maxp; 
obj.pEvaluateMannWhitney.stats.minp = minp;

end

function pv = MannWhitney(X, Y)
    groups = unique(Y); %assume Y has just 2 groups
    gp1 = Y==groups(1);
    gp2 = Y==groups(2);
    group1 = X(gp1); %separate the decomposed component into 2 groups as instructed by the confounding factor
    group2 = X(gp2);
    pv = ranksum(group1,group2); %Mann-Whitney
end