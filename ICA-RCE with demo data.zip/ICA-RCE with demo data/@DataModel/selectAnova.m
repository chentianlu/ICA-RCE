function selectMannWhitney(obj, selectedDCs, selectdCFs) 
%%
%INPUT
%selectedDCs: selected decomposed components, e.g. 1:3
%selectedCFs: selected confounding factors, e.g. 1:2
%
%STORED OUTPUT
%p: a vector P values, each the result of an Anova test between a 
%decomposed component and a confounding factor
%selectedICs: component numbers that corespond to the columns in p  
%%
%full set of decomposed components and confounding factors
decomposedComponents = obj.T;
confoundingFactors = obj.F;

%validate input value for selectedDCs
maxICs = size(decomposedComponents,2);
selectedDCs = selectedDCs(find(selectedDCs<=maxICs)); %make use of user selection, but only up to maxICs
%same for selectdCFs
maxICs = size(confoundingFactors,2);
selectdCFs = selectdCFs(find(selectdCFs<=maxICs)); %make use of user selection, but only up to maxICs

%make use of selected components only
decomposedComponents = decomposedComponents(:,selectedDCs);
confoundingFactors = confoundingFactors(:,selectdCFs);

dimX = size(decomposedComponents,2);
dimY = size(confoundingFactors,2);
pv = zeros(dimY,dimX);
%%
%Anova
for i=1:dimY %i is the index of the decomposed component
    for j=1:dimX %j is the index of the confounding factor
        data = decomposedComponents(:,j);
        grouping = confoundingFactors(:,i);
        pv(i,j) = anova1(data,grouping,'off');
    end
end
%%
%store p (a matrix) and its matching component numbers in rows and columns
%
obj.pSelectAnova.pv = pv;
obj.pSelectAnova.X = selectedDCs;
obj.pSelectAnova.Y = selectdCFs;

end