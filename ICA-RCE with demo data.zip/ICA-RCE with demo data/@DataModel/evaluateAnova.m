function evaluateAnova(obj, selectedRCs, selectdCVs) 
%INPUTS
%selectedRCs: selected removed components, e.g. 1:3
%selectdCVs: selected classification variable, e.g. 1:2
%
%OUTPUTS
%p: a structure with 4 fields as follows:
%p.pv: value of each X vector instructed by each vector in Y
%p.X: component numbers of removed components
%p.Y: component numbers of classification variables
%p.stats: a struct containing mean, meadian, max and min of p values for classifcation variables
%
%TECHNICAL DETAILS
%P = anova1(X,GROUP)
%X is a vector of values
%GROUP is a vector of groupings that matches with X
%Example:
%strength = [82 86 79 83 84 85 86 87 74 82 ...
%            78 75 76 77 79 79 77 78 82 79];
%alloy = [0 0 0 0 0 0 0 0 1 1 1 1 1 1  2 2 2 2 2 2]
%[p,tbl] = anova1(strength,alloy,'off')    
%In this case, p is small because the first material is different from the
%second and third material

%full set of removed components and classifcation variables
removedComponents = obj.T; %*obj.P';
classifcationVariables = obj.Y;

%validate input value for selectedRCs
maxICs = size(removedComponents,2);
selectedRCs = selectedRCs(find(selectedRCs<=maxICs)); %make use of user selection, but only up to maxICs
%same for selectdCVs
maxICs = size(classifcationVariables,2);
selectdCVs = selectdCVs(find(selectdCVs<=maxICs)); %make use of user selection, but only up to maxICs

%make use of selected components only
removedComponents = removedComponents(:,selectedRCs);
classifcationVariables = classifcationVariables(:,selectdCVs);

dimX = size(removedComponents,2);
dimY = size(classifcationVariables,2);
pv = zeros(dimY,dimX);
% test if variables (continuous) have the same mean
for i=1:dimY
    for j=1:dimX
        data = removedComponents(:,j);
        grouping = classifcationVariables(:,i);
        pv(i,j) = anova1(data,grouping,'off');
    end
end

%statistics in column vector, one value for each instructing factor
meanp = mean(pv, 2); %average across the removed components
medianp = median(pv,2);
maxp = max(pv')';
minp = min(pv')';
obj.pEvaluateAnova.pv = pv;
obj.pEvaluateAnova.X = selectedRCs;
obj.pEvaluateAnova.Y = selectdCVs;
obj.pEvaluateAnova.stats.meanp = meanp;
obj.pEvaluateAnova.stats.medianp = medianp; 
obj.pEvaluateAnova.stats.maxp = maxp; 
obj.pEvaluateAnova.stats.minp = minp;

end
