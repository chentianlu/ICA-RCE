classdef DataModel < handle
    %MODEL: this class will contain data and algorithms in the MVC design
    
    properties %the controller in the MVC design
        objController=[];
    end
    
    properties %input data and processed data
        %original data in data file
        Y0=[]; 
        F0=[]; 
        M0=[]; 
        %after data transformation and preprocessing
        Y=[]; %groups, each group in a column in the matrix Y 
        F=[]; %confounding factors, each confounding factor in a column in the matrix F
        M=[]; %metabolite measurements, each variable in a column in the matrix M
        %data after preprocessing       
        Z=[]; %corrected matrix (Z = X - TP'); Z has same size as M
        W=[]; %T=XW
        P=[]; %TP' has the same size as X
        T=[]; %orthogonal or independent components  
        ng=[];
        nc=[];
        nm=[];
        timeCPU=[];
        T2D=[];
        dEvaluatePLS=[];       
        evaluatePCAT2D=[];
        evaluatePCAR2X=[];
        pEvaluateMannWhitney=[]; %struct, p matrix, Y component numbers, X component numbers, and stats
        pEvaluateAnova=struct();
        rEvaluateCorrelation=[];
        pEvaluateLogisticRegression=[];
        pSelectMannWhitney=[];
        pSelectAnova=[];
        rSelectCorrelation=[];
        aSelectAUC=[];
    end

    properties
        %data file
        file=[]; 
        path=[]; 
        
        % user-selected choices
        transformoptions = struct('normalizationmode','newmax','newmin','logSelected','logbase','logconstant');
        
        preprocessmode=[];
        numICs = 2;
    end
       
    methods       
        function obj = DataModel(con) %constructor
            obj.objController = con;
        end            
    end 
    
    methods
        evaluatePLS(obj, selectedCVs);
    end
end

