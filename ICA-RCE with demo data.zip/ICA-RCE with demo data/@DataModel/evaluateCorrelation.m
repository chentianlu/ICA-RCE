function evaluateCorrelation(obj, selectedRCs, selectdCFs) 
%INPUTS
%selectedRCs: selected removed components, e.g. 1:3
%selectdCFs: selected confounding factors, e.g. 1:2
%
%OUTPUTS
%r: a structure with 4 fields as follows:
%r.rv: value of each X vector instructed by each vector in Y
%r.X: component numbers of removed components
%r.Y: component numbers of classification variables
%r.stats: a struct containing mean, meadian, max and min of r values for classifcation variables
%
%TECHNICAL DETAILS
%RHO = corr(X, Y)
%returns the pairwise correlation coefficient if X is a column and Y is a
%column also.
%'type','Spearman' will correlate ordinal (ranking) data
%%
%full set of removed components and confounding factors
removedComponents = obj.T; %obj.T*obj.P';
confoundingFactors = obj.F;

%validate input value for selectedRCs
maxRCs = size(removedComponents,2);
selectedRCs = selectedRCs(find(selectedRCs<=maxRCs)); %make use of user selection, but only up to maxICs
%same for selectdCFs
maxCFs = size(confoundingFactors,2);
selectdCFs = selectdCFs(find(selectdCFs<=maxCFs)); %make use of user selection, but only up to maxICs

%make use of selected components only
removedComponents = removedComponents(:,selectedRCs);
confoundingFactors = confoundingFactors(:,selectdCFs);

dimX = size(removedComponents,2);
dimY = size(confoundingFactors,2);
rv = zeros(dimY,dimX);
pv = zeros(dimY,dimX);
%%
%Spearman correlation coefficients of every confounding factor-removed component pair
for i=1:dimY %i is the index of confounding variable
    for j=1:dimX %j is the index of the metabolite
        [rv(i,j), pv(i,j)] = correlation(confoundingFactors(:,i), removedComponents(:,j));
    end
end
%%
%same as above, just that more correlation is done so that more results 
%are obtained in accordance with CLT's test results 
combined = [confoundingFactors removedComponents];
dimC = size(combined,2);
crv = zeros(dimC,dimC);
cpv = zeros(dimC,dimC);
for i=1:dimC %i is the index of confounding variable
    for j=1:dimC %j is the index of the metabolite
        [crv(i,j), cpv(i,j)] = correlation(combined(:,i), combined(:,j));
    end
end

%%
%statistics in column vector, one value for each instructing factor
meanr = mean(rv, 2); %average across the removed components
medianr = median(rv,2);
maxr = max(rv')';
minr = min(rv')';
obj.rEvaluateCorrelation.rv = rv;
obj.rEvaluateCorrelation.pv = pv;
obj.rEvaluateCorrelation.crv = crv;
obj.rEvaluateCorrelation.cpv = cpv;
obj.rEvaluateCorrelation.X = selectedRCs;
obj.rEvaluateCorrelation.Y = selectdCFs;
obj.rEvaluateCorrelation.stats.meanr = meanr;
obj.rEvaluateCorrelation.stats.medianr = medianr; 
obj.rEvaluateCorrelation.stats.maxr = maxr; 
obj.rEvaluateCorrelation.stats.minr = minr;
end

function [r,p] = correlation(X, CF) 
    [r,p] = corr(CF, X, 'type', 'spearman');
end
