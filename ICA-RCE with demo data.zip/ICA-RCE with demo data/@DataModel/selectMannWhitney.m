function selectMannWhitney(obj, selectedDCs, selectdCFs) 
%%
%INPUT
%selectedDCs: selected decomposed components, e.g. 1:3
%selectedCFs: selected confounding factors, e.g. 1:2
%
%STORED OUTPUT
%p: a vector P values, each the result of a Mann-Whitney U test between a 
%decomposed component and a confounding factor
%selectedICs: component numbers that corespond to the columns in p  
%
%%
%full set of decomposed components and confounding factors
decomposedComponents = obj.T;
confoundingFactors = obj.F;

%validate input value for selectedDCs
maxICs = size(decomposedComponents,2);
selectedDCs = selectedDCs(find(selectedDCs<=maxICs)); %make use of user selection, but only up to maxICs
%same for selectdCFs
maxICs = size(confoundingFactors,2);
selectdCFs = selectdCFs(find(selectdCFs<=maxICs)); %make use of user selection, but only up to maxICs

%make use of selected components only
decomposedComponents = decomposedComponents(:,selectedDCs);
confoundingFactors = confoundingFactors(:,selectdCFs);

dimX = size(decomposedComponents,2);
dimY = size(confoundingFactors,2);
pv = zeros(dimY,dimX);

%% 
%test if the confounding factors are acceptable (2 and only 2 groups per
%confounding factor)
%(applicable to Mann-Whitney only as it compares b/w two and only 2 groups)
acceptableSelectdCFs = true(1, dimY);
for i=1:dimY
    groups = unique(confoundingFactors(:,i));
    if (numel(unique(groups)) ~= 2)
        acceptableSelectdCFs(i)=false;
    end
end

%readjust classication variables to those that are acceptable
selectdCFs = selectdCFs(acceptableSelectdCFs);
confoundingFactors = confoundingFactors(:,acceptableSelectdCFs);
confoundingFactors = confoundingFactors(:,selectdCFs);
dimY = size(confoundingFactors,2);
%%
%Mann-Whitney
for i=1:dimY %i is the index of a confounding factor
    Y = confoundingFactors(:,i);
    for j=1:dimX %j is the index of a decomposed component
        X = decomposedComponents(:,j); %data is the vector containing the values of the decomposed component 
        pv(i,j) = MannWhitney(X, Y)
    end
end
%%
%store p (a matrix) and its matching component numbers in rows and columns
obj.pSelectMannWhitney.pv = pv;
obj.pSelectMannWhitney.X = selectedDCs;
obj.pSelectMannWhitney.Y = selectdCFs;

end

function pv = MannWhitney(X, Y)
    groups = unique(Y); %assume Y has just 2 groups
    gp1 = Y==groups(1);
    gp2 = Y==groups(2);
    group1 = X(gp1); %separate the decomposed component into 2 groups as instructed by the confounding factor
    group2 = X(gp2);
    pv = ranksum(group1,group2); %Mann-Whitney
end