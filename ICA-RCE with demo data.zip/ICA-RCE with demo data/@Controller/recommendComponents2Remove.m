function recommendComponents2Remove(obj)
    comps = obj.objModel.selectComponents(obj.objView.selectnumber2remove);
    nYs = obj.objView.evaluateclassificationvariablenumbers;
    obj.objView.updateEvaluation(comps, nYs);

end

