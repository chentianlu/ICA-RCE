function evaluateData(obj)   

    switch obj.objView.evaluatemode  
        case 'PLS'
            %entered by user in edit box in matlab convention, e.g. 1:3
            CVs = obj.objView.evaluateclassificationvariablenumbers; 
            obj.objModel.evaluatePLS(CVs);
            obj.objView.drawPLS2DPlot(obj.objModel.dEvaluatePLS);
            obj.objView.drawPLSPermutationPlot(obj.objModel.dEvaluatePLS);
            str1 = num2str(obj.objModel.dEvaluatePLS.R2X);
            str2 = num2str(obj.objModel.dEvaluatePLS.R2Y);
            str3 = num2str(obj.objModel.dEvaluatePLS.Q2);
            msgbox({'R2X';str1;'R2Y';str2;'Q2';str3},'modal');
                   
        case 'PCA'
            %entered by user in edit box in matlab convention, e.g. 1:3
            CVs = obj.objView.evaluateclassificationvariablenumbers; 
            obj.objModel.evaluatePCA(CVs);
            %Sample points in PCA scores plots should be highlighted by 
            %different groups. One group one figure.
            obj.objView.drawPCA2DPlot(obj.objModel.evaluatePCAT2D);
            str = ['R2X: ' num2str(obj.objModel.evaluatePCAR2X)];
            msgbox(str,'modal');  
            
        case 'Logistic Regression'           
            %P values of logistic regression of corrected components instructed by classification variables Y
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCVs = obj.objView.evaluateclassificationvariablenumbers;             
            %perform logistic regression (training using CC and CV, followed
            %by predicting of CC group membership probability
            obj.objModel.evaluateLogisticRegression(selectdCVs);
            %view bar plot (x axis is IC index, y axis is the P values, decending order) 
            p = obj.objModel.pEvaluateLogisticRegression;
            obj.objView.drawLogisticRegression(p);
            
        case 'P Values, Mann-Whitney'
            %P values of Mann-whitney U test of removed components instructed by classification variables Y
            selectedRCs = obj.objView.evaluateremovedcomponentnumbers;
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCVs = obj.objView.evaluateclassificationvariablenumbers;             
            %perform Mann Whitney
            obj.objModel.evaluateMannWhitney(selectedRCs, selectdCVs);
            %view bar plot (x axis is IC index, y axis is the P values, decending order) 
            p = obj.objModel.pEvaluateMannWhitney;
            obj.objView.drawMannWhitney(p); 
            
        case 'P Values, Anova'
            %P values of Anova test of removed components instructed by the classification variables
            selectedRCs = obj.objView.evaluateremovedcomponentnumbers;
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCVs = obj.objView.evaluateclassificationvariablenumbers;            
            %perform anova
            obj.objModel.evaluateAnova(selectedRCs, selectdCVs);
            %view bar plot (x axis is IC index, y axis is the P values, decending order) 
            p = obj.objModel.pEvaluateAnova;
            obj.objView.drawAnova(p);             
        
        case 'Correlation'
            %R values of correlation of removed components instructed by the classification variables
            selectedRCs = obj.objView.evaluateremovedcomponentnumbers;
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCFs = obj.objView.evaluateclassificationvariablenumbers; %KBH:CF will share the edit box with class. vars           
            %perform correlation
            obj.objModel.evaluateCorrelation(selectedRCs, selectdCFs);
            %view bar plot (x axis is IC index, y axis is the coefficients, decending order) 
            r = obj.objModel.rEvaluateCorrelation;
            obj.objView.drawCorrelation(r); 

        case 'CPU Time'
            str1 = sprintf('PC-OSC: \t \t %f', obj.objModel.timeCPU.PCOSC);
            str2 = sprintf('DOSC: \t \t %f', obj.objModel.timeCPU.DOSC);
            str3 = sprintf('ICA: \t \t %f', obj.objModel.timeCPU.ICA);
 
            msgbox({str1;str2;str3},'modal'); 
    end
               
end

