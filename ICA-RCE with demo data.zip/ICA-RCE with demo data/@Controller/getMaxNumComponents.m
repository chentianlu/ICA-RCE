function num  = getMaxNumComponents(obj)
    num = min(size(obj.objModel.M));
end

