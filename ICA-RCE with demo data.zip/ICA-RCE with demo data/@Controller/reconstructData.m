function reconstructData(obj)    
    obj.objModel.reconstructData(obj.objView.evaluateremovedcomponentnumbers);
            
    %selectedCVs = obj.objView.evaluateclassificationvariablenumbers;      
    %obj.objModel.evaluatePCA(selectedCVs);
    %Sample points in PCA scores plots should be highlighted by 
    %different groups. One group one figure.
    %obj.objView.drawPCA2DPlot(obj.objModel.evaluatePCAT2D);
    %str = ['R2X: ' num2str(obj.objModel.evaluatePCAR2X)];
    %msgbox(str,'modal'); 
    
end