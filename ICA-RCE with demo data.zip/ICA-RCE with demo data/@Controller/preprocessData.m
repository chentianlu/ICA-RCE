function preprocessData(obj) 
    %reload stored data of input file
    obj.objModel.reloadData();
    %DATA TRANSFORMATION 
    %get user-selected parameters from UI, then call Controller to perform the transformation
    options.normalizationmode = obj.objView.normalizationmode;
    options.newmax = obj.objView.newmax;
    options.newmin = obj.objView.newmin;
    options.logselected = obj.objView.logselected;
    options.logbase = obj.objView.logbase;
    options.logconstant = obj.objView.logconstant;
    obj.objModel.transformData(options);

    %PREPROCESS
    obj.objModel.preprocessData(obj.objView.preprocessmode, obj.objView.numDCs);
    
    %DISPLAYG  
    %display default decomposed component numbers and classification variables on GUI
    maxDCs = min(size(obj.objModel.T));
    maxCFs = min(size(obj.objModel.F));
    
    if (obj.objView.numDCs > maxDCs)
        selectedDCs = maxDCs;
    else
        selectedDCs = obj.objView.numDCs;
    end
    
    if strcmp(obj.objView.preprocessmode,'RAW')
        selectedDCs = maxDCs;
    end        
    obj.objView.updateSelection(['1:' num2str(selectedDCs)], ['1:' num2str(maxCFs)]);

    %display default removed component numbers and classification variables on GUI
    maxRCs = min(size(obj.objModel.M));
    maxYs = min(size(obj.objModel.Y));
    obj.objView.updateEvaluation(['1:' num2str(maxRCs)], ['1:' num2str(maxYs)]);

    
    obj.objView.displayCPUTime(obj);
end


