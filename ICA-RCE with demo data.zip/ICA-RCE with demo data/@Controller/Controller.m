classdef Controller < handle %it is necessary to inherit from handle to make members persistent in callbacks
    %Controller in MVC model
    properties %MVC
        objView=[];
        objModel=[];
    end
       
    properties %data file
        file=[]; %file name of data file (csv or xls)
        path=[]; %path of above file
        libpath=[]; %path of dosc & fastica 
    end
    
    properties (Access = private)
        strEvaluation=[];
        strSelection=[];
    end
            
    methods %constructor and destructor
        function obj = Controller() % constructor of Controller class  
            %concatenation of paths with ";" as separator
            obj.libpath = [pwd '\dosc;' pwd '\FastICA_25' ];
            %add dosc & fastica to Matlab path (has to be removed in destructor)
            addpath(obj.libpath);
            %call constructor of View (graphs) and Model (data and algorithms) 
            obj.objView = View(obj);           
            obj.objModel = DataModel(obj);
        end
        
        function delete(obj) %destructor of Controller class
            close all %close all figures, including GUI
            rmpath(obj.libpath); %remove path of dosc and fastica from Matlab path
        end
    end
end    