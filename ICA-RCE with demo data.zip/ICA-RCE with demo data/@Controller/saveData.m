function bool = saveData(obj)
    bool = obj.objModel.saveData();
end

