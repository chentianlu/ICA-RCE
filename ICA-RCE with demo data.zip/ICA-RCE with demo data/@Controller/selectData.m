function selectData(obj)   
%Additional outputs for ICA and EMD based methods 
%
    switch obj.objView.selectionmode
        case 'Scatter Plots'
            %display each and every decomposed components that are selected
            %by the user for viewing on a floating figure
            decomposedComponents = obj.objModel.T;
            selectedICs = obj.objView.selectdecomposedcomponentnumbers; %entered by user in edit box in matlab convention, e.g. 1:3
            obj.objView.drawLinePlot(decomposedComponents, selectedICs);   
        case 'P Values, Mann-Whitney'
            %P values of Mann-whitney U test of decomposed components instructed by confounding factors
            selectedDCs = obj.objView.selectdecomposedcomponentnumbers;  
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCFs = obj.objView.selectconfoundingfactornumbers;
            %Mann-Whitney
            obj.objModel.selectMannWhitney(selectedDCs,selectdCFs);
            %view bar plot (x axis is IC index, y axis is P values, decending order) 
            p = obj.objModel.pSelectMannWhitney;
            obj.objView.drawMannWhitney(p); 
        case 'P Values, Anova'
            %P values of Anova test of decomposed ICs instructed by the confounding factor.
            selectedDCs = obj.objView.selectdecomposedcomponentnumbers; %entered by user in edit box in matlab convention, e.g. 1:3
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCFs = obj.objView.selectconfoundingfactornumbers;
            %Anova
            obj.objModel.selectAnova(selectedDCs,selectdCFs);
            %view bar plot (x axis is IC index, y axis is the P values, decending order) 
            p = obj.objModel.pSelectAnova;
            obj.objView.drawAnova(p);             
        case 'Spearman Correlation'
            %R values of Spearman coefficients of decomposed ICs instructed by the confounding factor.
            selectedDCs = obj.objView.selectdecomposedcomponentnumbers; %user-selection, in Matlab convention, e.g. 1,2,3
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCFs = obj.objView.selectconfoundingfactornumbers;            
            %Spearman correlation (by ranking positions)
            obj.objModel.selectCorrelation(selectedDCs,selectdCFs);
            %view bar plot (x axis is IC index, y axis is the coefficients, decending order) 
            r = obj.objModel.rSelectCorrelation;
            obj.objView.drawCorrelation(r);  
        case 'AUC'
            %auc values of ROC of decomposed ICs instructed by the confounding factor.
            selectedDCs = obj.objView.selectdecomposedcomponentnumbers; %user-selection, in Matlab convention, e.g. 1,2,3
            %entered by user in edit box in matlab convention, e.g. 1:3
            selectdCFs = obj.objView.selectconfoundingfactornumbers;            
            %auc 
            obj.objModel.selectAUC(selectedDCs,selectdCFs);
            %view bar plot (x axis is IC index, y axis is the coefficients, decending order) 
            a = obj.objModel.aSelectAUC;
            obj.objView.drawAUC(a);             
    end
end