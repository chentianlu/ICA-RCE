function openFile(obj, file, path)
    obj.objModel.inputData(file, path);
    obj.objModel.initializeData();
    obj.objView.displayInfo(obj);
end 