function drawPLS2DPlot(obj, dEvaluatePLS)

T = dEvaluatePLS.T;

linespec = {'r.', 'b.'}; % define color formats for use in a loop
       
for i=1:size(T,2)
    str = ['PLS Score Plot based on Classification Variable ' num2str(i)];
    figure('Name',str,'NumberTitle', 'off');
    for j=1:size(T(i).group,2) %by group
        values = T(i).group(j).values; %values are XS
        scatter(values(:,1),values(:,2),linespec{j}); % the independent signals be uncorrelated in the scatter plot
        xlabel('t1'); ylabel('t2');
        hold all
        drawnow;
    end
end
    
end
