function updateEvaluation(obj, nRC, nY)

    set(obj.hEditEvaluateRemovedComponentNumbers, 'String', num2str(nRC));
    
    set(obj.hEditEvaluateClassificationVariableNumbers, 'String', num2str(nY));
end


