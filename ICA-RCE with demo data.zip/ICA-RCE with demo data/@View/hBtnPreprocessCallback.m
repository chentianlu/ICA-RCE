function hBtnPreprocessCallback(obj, src, event)
    %ask the Controller object to get the Model object to preprocess the data
    obj.objController.preprocessData();  
    
    %enable the display of the selection panel on the bottom right of the GUI 
    switch obj.preprocessmode
        case 'ICA' %enable selection panel
            set(findall(obj.hPanelBottomRight, '-property', 'enable'), 'enable', 'on');
        otherwise %disable selection panel   
            set(findall(obj.hPanelBottomRight, '-property', 'enable'), 'enable', 'on');
    end
    %disable evaluate panel
    set(findall(obj.hPanelBottomLeft, '-property', 'enable'), 'enable', 'on')
    %display status message
    obj.displayStatus(['Preprocessed: ' obj.preprocessmode ' OK']);
end