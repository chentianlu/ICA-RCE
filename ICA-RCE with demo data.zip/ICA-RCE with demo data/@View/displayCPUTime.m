function displayCPUTime(obj, con)
    str = ['PC-OSC: ' num2str(con.objModel.timeCPU.PCOSC) '; DOSC: ' num2str(con.objModel.timeCPU.DOSC) '; ICA: ' num2str(con.objModel.timeCPU.ICA) '; RAW: ' num2str(con.objModel.timeCPU.RAW)]; 
    set(obj.hLabelRight,'String', str);
end