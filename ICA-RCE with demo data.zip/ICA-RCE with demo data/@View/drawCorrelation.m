function drawCorrelation(obj, r)
%
%this function is used in two places: during evaluation and selection process.
%
%INPUT
%r: IxJ matrix, where I is number of classification variables/confounding factors, and J is number of removed components/decomposed components 
%
dimX = size(r.X,2); %removed components (during evaluation) or decomposed components (during selection)
dimY = size(r.Y,2); %classifcation variables (during evaluation) or confounding factors (during selection)

figure('Name','Correlation','NumberTitle', 'off');
str=cell(1); %initalize an empty cell array to store component names

% confounding factor-removed component pair
for i=1:dimY
    for j=1:dimX
        str{j}=['C' num2str(r.X(j))]; % concatenate the component name for bar display                
    end
    subplot(dimY, 1, i);
    [rv, index] = sort(r.rv(i,:),'descend');
    bar(rv);
    ylabel(['r coeff ' num2str(r.Y(i))]);
    %display the component name, in descending order
    str = str(index);
    set(gca, 'XTickLabel',str, 'XTick',1:numel(str));
    drawnow;            
end
end