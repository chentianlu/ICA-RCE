function drawAnova(obj, p) 
%
%this function is used in two places: during evaluation and selection process.
%
%INPUT
%p: IxJ matrix, where I is number of classification variables/confounding factors, and J is number of removed components/decomposed components 
%
dimX = size(p.X,2); %removed components (during evaluation) or decomposed components (during selection)
dimY = size(p.Y,2); %classifcation variables (during evaluation) or confounding factors (during selection)

figure('Name','P Values, Anova','NumberTitle', 'off');
str=cell(1); %initalize an empty cell array to store component names

for i=1:dimY
    for j=1:dimX
        str{j}=['C' num2str(p.X(j))]; % concatenate the component name for bar display
    end
    subplot(dimY, 1, i);
    [pv, index] = sort(p.pv(i,:),'descend');
    bar(pv);
    ylabel(['p value ' num2str(p.Y(i))]);
    %display the component name, in descending order
    str = str(index);
    set(gca, 'XTickLabel',str, 'XTick',1:numel(str));
    drawnow;
end
end


