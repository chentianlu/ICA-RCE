function displayStatus(obj, str)
     set(obj.hLabelLeft,'String', str);
end  