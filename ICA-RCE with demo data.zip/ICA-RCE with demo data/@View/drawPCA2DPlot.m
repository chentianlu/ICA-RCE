function drawPCA2DPlot(obj, T)

linespec = {'r.', 'b.', 'b.', 'k.'}; % define color formats for use in a loop

for i=1:size(T,2)
    str = ['Score Plot: Classification Variable ' num2str(i)];
    figure('Name',str,'NumberTitle', 'off');
    for j=1:size(T(i).group,2) %by group
        values = T(i).group(j).values;
        h = scatter(values(:,1),values(:,2),linespec{j}); % the independent signals be uncorrelated in the scatter plot
        hold all
        drawnow;
    end
end
end
