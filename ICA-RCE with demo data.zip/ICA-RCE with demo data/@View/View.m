classdef View < handle
    %View in MVC model
    %This file defines the GUI only
    %The UI handlers are in separate files in the current folder (@View)
    %Graph drawing functions are in separate files in the current folder (@View)
    
    properties %MVC
        objController=[];
    end
    
    properties (Constant, Access = private)
        %Evaluation (comparing corrected M with Y)
        strEvaluation = {...      
          'PLS';
          'PCA';
          'Logistic Regression'; 
          'P Values, Mann-Whitney';
          'P Values, Anova';
          'CPU Time';
          'Correlation';
        };
        %Selection (comparing decomposed M with CF)
        strSelection = {...      
          'Scatter Plots';
          'AUC'; 
          'P Values, Mann-Whitney';
          'P Values, Anova';
          'Spearman Correlation';
        };        
    end

    properties
        hGUI=[];
        hAxes=[];
    end
    
    properties % panels
        hPanelLeft=[]; %normalization and decomposition methods
        hPanelBottomLeft=[]; %selection choices
        hPanelBottomRight=[]; %evaluation choices
        hPanelStatusBar=[]; %general information
    end
    
    properties %hPanelLeft (normalization and decomposition methods)   
        hBtnGrpNormalize=[];
        hEditNewMax=[];
        hEditNewMin=[];
        hCheckboxLogTransform=[];
        hEditBase=[];
        hEditConstant=[];
        hBtnGrpPreprocess=[];
        hEditNumDCs=[];
        hBtnPreprocessRun=[];        
    end

    properties %hPanelBottomLeft (selection choices)
        hEditSelectDecomposedComponentNumbers=[];
        hPopupmenuSelect=[];        
        hEditSelectConfoundingFactorNumbers=[];
        hBtnRecommend=[];
        hBtnReconstruct=[];
    end
    
    properties %hPanelBottomRight (evaluation choices)
        hEditEvaluateRemovedComponentNumbers=[];
        hEditSelectNumber2Remove=[]
        hPopupmenuEvaluate=[];
        hEditEvaluateClassificationVariableNumbers=[];        
    end

    properties %hPanelBottomRight (general information)  
        hLabelLeft=[];
        hLabelCenter=[];
        hLabelRight=[];
    end
    
    properties %user-selectable parameters (set and get are listed at the end of this file)
        normalizationmode;
        newmax;
        newmin;
        logselected;
        logbase;
        logconstant;
        preprocessmode;
        numDCs;
        %selection
        selectdecomposedcomponentnumbers; %column numbers of T, e.g. 1,2, 3 or 1:3
        selectionmode; 
        selectconfoundingfactornumbers; %column numbers of F, e.g. 1,2, 3 or 1:3
        selectnumber2remove;
        %evaluation
        evaluateremovedcomponentnumbers;
        evaluatemode;
        evaluateclassificationvariablenumbers; %column numbers of Y, e.g. 1,2, 3 or 1:3
    end
    
    methods
        function obj = View(con) %constructor
            obj.objController = con;
            %create a new figure window that fits with the screen size
            screen = get(0, 'ScreenSize');
            W = screen(3); H = screen(4);
            obj.hGUI = figure('Color', [0.6, 0.6, 0.6], 'Position', [0.15*W, 0.15*H, 0.7*W, 0.7*H], 'Name', 'Denoise','NumberTitle', 'off', 'MenuBar', 'none');
            %create a new axis for plotting XY graph
            obj.hAxes = axes('Parent', obj.hGUI, 'Position', [0.3, 0.4, 0.6, 0.5], 'XLim', [-1, 1], 'YLim', [-1, 1]);
            axis equal;
            axis manual;
            axis off;
            box on
      
            %%%menu and toolbar%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            hFileMenu = uimenu('Label','File','Parent',obj.hGUI,'HandleVisibility','callback');
            uimenu('Label','Open','Parent',hFileMenu,'HandleVisibility','callback','Callback', @(src, event) hMenuitemOpenCallback(obj, src, event));
            uimenu('Label','Save Data','Parent',hFileMenu,'HandleVisibility','callback','Callback', @(src, event) hMenuitemSaveCallback(obj, src, event));
            uimenu('Label','Close','Parent',hFileMenu,'Separator','on','HandleVisibility','callback','Callback', @(src, event) hMenuitemCloseCallback(obj, src, event));
            
            hToolbar = uitoolbar('Parent',obj.hGUI, 'HandleVisibility','callback');
            iconimg = load(fullfile(matlabroot,'toolbox\matlab\icons\opendoc.mat'));
            uipushtool('TooltipString','Open File','Parent',hToolbar,'CData',iconimg.cdata,'HandleVisibility','callback','ClickedCallback', @(src, event) hMenuitemOpenCallback(obj, src, event));
            iconimg = load(fullfile(matlabroot,'toolbox\matlab\icons\savedoc.mat'));
            uipushtool('TooltipString','Save Data','Parent',hToolbar,'CData',iconimg.cdata,'HandleVisibility','callback','ClickedCallback', @(src, event) hMenuitemSaveCallback(obj, src, event));
                
            %%%panels%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.hPanelLeft = uipanel('Position',[0 0.05 0.25 0.95], 'Units','Normalized'); 
            hPanelDataTransform = uipanel('Title', 'Data Transform','Units','Normalized','Parent',obj.hPanelLeft,'Position',[0 0.6 1 0.4]);
            hPanelPreprocess = uipanel('Title', 'Pre-Process','Parent',obj.hPanelLeft,'Position',[0 0 1 0.6],'Units','Normalized');
            obj.hPanelBottomLeft = uipanel('Title', 'ICA Selection','Units','Normalized','Position',[0.25 0.05 0.35 0.3]);
            obj.hPanelBottomRight = uipanel('Title', 'Evaluate','Units','Normalized','Position',[0.6 0.05 0.4 0.3]);
            obj.hPanelStatusBar = uipanel('Units','Normalized','Position',[0 0 1 0.05]);

            %%%NORMALIZE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pPanelSub1 = uipanel('Parent',hPanelDataTransform, 'Units','Normalized', 'Position',[0 0.5 0.65 0.5],'BorderWidth',0);
            obj.hBtnGrpNormalize = uibuttongroup('Parent',pPanelSub1, 'Position',[0 0 1 1], 'Units','Normalized','BorderWidth',0);
            uicontrol('String','None','Style','Radio', 'Parent',obj.hBtnGrpNormalize, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.7, 0.9, 0.25])
            uicontrol('String','Normalize by Variable','Style','Radio', 'Parent',obj.hBtnGrpNormalize, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.4, 0.9, 0.25])
            uicontrol('String','Normalize by Sample','Style','Radio', 'Parent',obj.hBtnGrpNormalize, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.1, 0.9, 0.25])
            
            pPanelSub2 = uipanel('Parent',hPanelDataTransform, 'Units','Normalized', 'Position',[0.65 0.5 0.35 0.5],'BorderWidth',0);
            uicontrol('String', 'Max','Style', 'Text', 'Parent', pPanelSub2, 'Units', 'normalized', 'Position', [0.05, 0.6, 0.5, 0.25]);
            obj.hEditNewMax = uicontrol('String', '1.0','Style', 'Edit', 'Parent', pPanelSub2, 'Units', 'normalized', 'Position', [0.65, 0.6, 0.3, 0.25], 'Back', [0, 1, 1]);   
            uicontrol('String', 'Min', 'Style', 'Text', 'Parent', pPanelSub2, 'Units', 'normalized', 'Position', [0.05, 0.2, 0.5, 0.25]);
            obj.hEditNewMin = uicontrol('String', '0.0','Style', 'Edit', 'Parent', pPanelSub2, 'Units', 'normalized', 'Position', [0.65, 0.2, 0.3, 0.25], 'Back', [0, 1, 1]);   
            %cosmetic panel only
            uipanel('Parent',hPanelDataTransform, 'Units','Normalized', 'Position',[0 0.5 1 0.5],'BorderWidth',1);
            
            %%%LOG TRANSFORM%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pPanelSub3 = uipanel('Parent',hPanelDataTransform, 'Units','Normalized', 'Position',[0 0 0.6 0.5],'BorderWidth',0);
            %obj.hLogTransformBtnGrp = uibuttongroup('Parent',pPanelSub3, 'Units','Normalized', 'Position',[0 0 1 1]);
            obj.hCheckboxLogTransform = uicontrol('Style','Checkbox', 'Parent',pPanelSub3, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.5, 0.9, 0.25], 'String','Log Transform');
            
            pPanelSub4 = uipanel('Parent',hPanelDataTransform,'Units', 'Normalized', 'Position',[0.6 0 0.4 0.5],'BorderWidth',0);
            uicontrol('Style', 'Text', 'Parent', pPanelSub4, 'Units', 'normalized', 'Position', [0.05, 0.6, 0.5, 0.25], 'String', 'Base');
            obj.hEditBase = uicontrol('Style', 'Edit', 'Parent', pPanelSub4, 'Units', 'normalized', 'Position', [0.65, 0.6, 0.3, 0.25], 'Back', [0, 1, 1], 'String', '2');   
            uicontrol('Style', 'Text', 'Parent', pPanelSub4, 'Units', 'normalized', 'Position', [0.05, 0.2, 0.5, 0.25], 'String', 'Constant');
            obj.hEditConstant = uicontrol('Style', 'Edit', 'Parent', pPanelSub4, 'Units', 'normalized', 'Position', [0.65, 0.2, 0.3, 0.25], 'Back', [0, 1, 1], 'String', '0.01');   

            %cosmetic only
            uipanel('Parent',hPanelDataTransform, 'Units','Normalized', 'Position',[0 0 1 0.5]);
            
            %%%PRE-PROCESS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            pPanelSub5 = uipanel('Parent',hPanelPreprocess, 'Units', 'Normalized', 'Position',[0 0.2 0.4 0.8],'BorderWidth',0);
            obj.hBtnGrpPreprocess = uibuttongroup('Parent',pPanelSub5,'Units','Normalized', 'Position',[0 0 1 1],'BorderWidth',0);
            uicontrol('String','PC-OSC','Style','Radio', 'Parent',obj.hBtnGrpPreprocess, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.85, 0.8, 0.15])
            uicontrol('String','DOSC','Style','Radio', 'Parent',obj.hBtnGrpPreprocess, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.65, 0.8, 0.15])
            uicontrol('String','ICA','Style','Radio', 'Parent',obj.hBtnGrpPreprocess, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.45, 0.8, 0.15])
            uicontrol('String','RAW','Style','Radio', 'Parent',obj.hBtnGrpPreprocess, 'HandleVisibility','off', 'Units','Normalized', 'Position',[0.05, 0.25, 0.8, 0.15])
            set(obj.hBtnGrpPreprocess, 'SelectionChangeFcn',@(src, event) hBtnGrpPreprocessCallback(obj, src, event));

            pPanelSub6 = uipanel('Parent',hPanelPreprocess, 'Units','Normalized', 'Position',[0.4 0.2 0.6 0.8],'BorderWidth',0);
            uicontrol('String', 'No. of components','Style', 'Text', 'Parent', pPanelSub6, 'Units', 'normalized', 'Position', [0.05, 0.7, 0.5, 0.15]);
            obj.hEditNumDCs = uicontrol('String', '2','Style', 'Edit', 'Parent', pPanelSub6, 'Units', 'normalized', 'Position', [0.65, 0.7, 0.3, 0.15], 'Back', [0, 1, 1]);   
          
            pPanelSub7 = uipanel('Parent', hPanelPreprocess, 'Units', 'Normalized', 'Position',[0 0 1 0.2],'BorderWidth',0);
            obj.hBtnPreprocessRun = uicontrol('String','Preprocess','Parent',pPanelSub7,'Units','Normalized', 'Position',[0.1 0.3 0.8 0.5],'Callback',@(src, event) hBtnPreprocessCallback(obj, src, event));

            %%%ICA SELECT%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
            pPanelSub8 = uipanel('Parent',obj.hPanelBottomLeft, 'Units','Normalized', 'Position',[0 0 1 1]);
            uicontrol('String', 'Decomposed component indices','Style', 'Text', 'Parent', pPanelSub8, 'Units', 'normalized', 'Position', [0.025, 0.7, 0.35, 0.25]);           
            obj.hEditSelectDecomposedComponentNumbers = uicontrol('String', '1,2','Style', 'Edit', 'Parent', pPanelSub8, 'Units', 'normalized', 'Position', [0.025, 0.4, 0.35, 0.2], 'Back', [0, 1, 1]);                  
            %popup menu will display the strings in strSelection
            obj.hPopupmenuSelect = uicontrol('String', obj.strSelection(:,1),'Style','popupmenu', 'Parent', pPanelSub8, 'Units','normalized', 'Position',[0.4, 0.7, 0.3, 0.25], 'HandleVisibility','callback','Callback', @(src, event) hPopupmenuSelectCallback(obj, src, event));
            obj.hBtnRecommend = uicontrol('String','Recommend','Parent',pPanelSub8,'Units','Normalized', 'Position',[0.4 0.4 0.3 0.2],'Callback',@(src, event) hBtnRecommendCallback(obj, src, event));
            obj.hBtnReconstruct = uicontrol('String','Reconstruct','Parent',pPanelSub8,'Units','Normalized', 'Position',[0.4 0.1 0.3 0.2],'Callback',@(src, event) hBtnReconstructCallback(obj, src, event));
            %specify the instructor (confounding factor)
            uicontrol('String', 'Instructors (CF)','Style', 'Text', 'Parent', pPanelSub8, 'Units', 'normalized', 'Position', [0.75, 0.7, 0.2, 0.25]);           
            obj.hEditSelectConfoundingFactorNumbers = uicontrol('String', '1','Style', 'Edit', 'Parent', pPanelSub8, 'Units', 'normalized', 'Position', [0.75, 0.4, 0.2, 0.2], 'Back', [0, 1, 1]);                  

            %%%EVALUATE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
            pPanelSub9 = uipanel('Parent',obj.hPanelBottomRight, 'Units','Normalized', 'Position',[0 0 1 1]);
            uicontrol('String', 'Removed component indices','Style', 'Text', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.025, 0.7, 0.35, 0.25]);           
            obj.hEditEvaluateRemovedComponentNumbers = uicontrol('String', '1,2','Style', 'Edit', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.025, 0.5, 0.35, 0.2], 'Back', [0, 1, 1]);                  
            %number of removed components
            uicontrol('String', 'Number of components to remove','Style', 'Text', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.025, 0.3, 0.35, 0.2]);           
            obj.hEditSelectNumber2Remove = uicontrol('String', '2','Style', 'Edit', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.025, 0.05, 0.35, 0.2], 'Back', [0, 1, 1]);                  
            %popup menu will display the strings in strEvaluation
            obj.hPopupmenuEvaluate = uicontrol('String', obj.strEvaluation(:,1),'Style','popupmenu', 'Parent', pPanelSub9, 'Units','normalized', 'Position',[0.4, 0.7, 0.3, 0.25], 'HandleVisibility','callback','Callback', @(src, event) hPopupmenuEvaluateCallback(obj, src, event));
            %specify the instructor (classification variable)
            uicontrol('String', 'Instructors (Y)','Style', 'Text', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.75, 0.7, 0.2, 0.25]);           
            obj.hEditEvaluateClassificationVariableNumbers = uicontrol('String', '1','Style', 'Edit', 'Parent', pPanelSub9, 'Units', 'normalized', 'Position', [0.75, 0.4, 0.2, 0.2], 'Back', [0, 1, 1]);                             
                        
            %%%STATUS BAR%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            obj.hLabelLeft = uicontrol('Style', 'Text', 'Parent', obj.hPanelStatusBar, 'Units', 'normalized', 'Position', [0.0, 0.2, 0.2, 0.7],'HorizontalAlignment','Left');
            obj.hLabelCenter = uicontrol('Style', 'Text', 'Parent', obj.hPanelStatusBar, 'Units', 'normalized', 'Position', [0.2, 0.2, 0.5, 0.7],'HorizontalAlignment','Center');
            obj.hLabelRight = uicontrol('Style', 'Text', 'Parent', obj.hPanelStatusBar, 'Units', 'normalized', 'Position', [0.7, 0.2, 0.3, 0.7],'HorizontalAlignment','Right');
            
            %disable panels until file is selected
            set(findall(obj.hPanelLeft, '-property', 'enable'), 'enable', 'off');
            set(findall(obj.hPanelBottomLeft, '-property', 'enable'), 'enable', 'off');
            set(findall(obj.hPanelBottomRight, '-property', 'enable'), 'enable', 'off');
        end      
    end

    methods (Access = private) %callback functions of ui (implementations are inside @View folder)
        hMenuitemOpenCallback(obj, src, event);
        hMenuitemSaveCallback(obj, src, event);
        hMenuitemCloseCallback(obj, src, event);        
        hBtnPreprocessCallback(obj, src, event);
        hPopupmenuEvaluateCallback(obj, src, event);    
        hPopupmenuSelectCallback(obj, src, event);
        hBtnReconstructCallback(obj, src, event);
    end 
    
    methods %set and get
        function normalizationmode = get.normalizationmode(obj)
            normalizationmode = get(get(obj.hBtnGrpNormalize,'SelectedObject'),'String');
        end
                
        function newmax = get.newmax(obj)
            newmax = str2num(get(obj.hEditNewMax,'String'));
        end
        
        function newmin = get.newmin(obj)
            newmin = str2num(get(obj.hEditNewMin,'String'));
        end

        function logSelected = get.logselected(obj)
            logSelected = get(obj.hCheckboxLogTransform,'Value');
        end
                
        function logbase = get.logbase(obj)
            logbase = str2num(get(obj.hEditBase,'String'));
        end
        
        function logconstant = get.logconstant(obj)
            logconstant = str2num(get(obj.hEditConstant,'String'));
        end   
        
        function preprocessmode = get.preprocessmode(obj)
            preprocessmode = get(get(obj.hBtnGrpPreprocess,'SelectedObject'),'String');
        end
 
        function numDCs = get.numDCs(obj)
            numDCs = str2num(get(obj.hEditNumDCs,'String'));
        end         
        
        function evaluateremovedcomponentnumbers = get.evaluateremovedcomponentnumbers(obj)
            %after str2num, output will be a vector, e.g. '1:2:4' will become [1 3]
            evaluateremovedcomponentnumbers = str2num(get(obj.hEditEvaluateRemovedComponentNumbers,'String'));
        end
        
        function evaluatemode = get.evaluatemode(obj)
            evaluateindex = get(obj.hPopupmenuEvaluate,'Value');
            evaluatemode = char(obj.strEvaluation(evaluateindex, 1));
        end        
 
        function evaluateclassificationvariablenumbers = get.evaluateclassificationvariablenumbers(obj)
            %after str2num, output will be a vector, e.g. '1:2:4' will become [1 3]
            evaluateclassificationvariablenumbers = str2num(get(obj.hEditEvaluateClassificationVariableNumbers,'String'));
        end
  
        function selectdecomposedcomponentnumbers = get.selectdecomposedcomponentnumbers(obj)
            %after str2num, output will be a vector, e.g. '1:2:4' will become [1 3]
            selectdecomposedcomponentnumbers = str2num(get(obj.hEditSelectDecomposedComponentNumbers,'String'));
        end  
        
        function selectionmode = get.selectionmode(obj)
            selectionindex = get(obj.hPopupmenuSelect,'Value');
            selectionmode = char(obj.strSelection(selectionindex, 1));
        end 
               
        function selectconfoundingfactornumbers = get.selectconfoundingfactornumbers(obj)
            %after str2num, selectconfoundingfactors will become a vector, e.g. '1:2:4'
            %will become [1 3]
            selectconfoundingfactornumbers = str2num(get(obj.hEditSelectConfoundingFactorNumbers,'String'));
        end

        function selectnumber2remove = get.selectnumber2remove(obj)
            selectnumber2remove = str2num(get(obj.hEditSelectNumber2Remove,'String'));
        end       
    end
end