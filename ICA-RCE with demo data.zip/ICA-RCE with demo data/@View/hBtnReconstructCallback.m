function hBtnReconstructCallback(obj, src, event)   
    obj.objController.reconstructData();    
    obj.displayStatus(['Reconstructed: ' ' OK']);
        
end 