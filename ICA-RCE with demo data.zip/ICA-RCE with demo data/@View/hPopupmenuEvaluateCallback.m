function hPopupmenuEvaluateCallback(obj, src, event)       
    obj.objController.evaluateData();
end