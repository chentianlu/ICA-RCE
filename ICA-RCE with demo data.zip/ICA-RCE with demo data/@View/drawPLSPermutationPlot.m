function drawPLSPermutationPlot(obj, dEvaluatePLS)
%plot of pre-preprocess's versus post-preprocess's permuted R2 and Q2 values
%permutation plot is useful (compared to traditional linear model significance tests)
%when the data are sampled from unkown distributions

permute = dEvaluatePLS.permute;
R2Y = dEvaluatePLS.R2Y;
Q2 = dEvaluatePLS.Q2;

%X axis: correlation coefficient between the original Y (pre) and the permuted Y (post) 
%Y axis: the CUMULATIVE R2Y and Q2 of all the components (Y axis)
%draws the regression line. 
%The intercept (R2 and Q2 when correlation coefficient is zero) is a measure of the over fit.
%
%R2X and R2Y denote the fraction of the Sum of Squares (SS) of all the Y's and X's 
%explained by all the components. R2=1-RSS/SS.
%Q2 denotes the fraction of the total variation of the X's that can be 
%predicted by a component, as estimated by cross-validation.
%Q2 =1.0 - PRESS/SS

%%
dimY =size(permute, 1);
for i=1:dimY %i is the index for the classification variable
    str = ['Permutation Plot based on Classification Variable ' num2str(i)];
    figure('Name',str,'NumberTitle', 'off');
    %display R2Y
    scatter(R2Y(i,1),R2Y(i,2),'b^'); hold on    
    scatter(permute(i).R2Y(:,1),permute(i).R2Y(:,2),'bo'); hold on
    centroidR2Y=mean(permute(i).R2Y);
    %draw a line joining a point (R2Y) to the centroid 
    plot([R2Y(i,1) centroidR2Y(1)],[R2Y(i,2) centroidR2Y(2)],'k'); %plot a line joining centroid to actual
    hold on
    %display Q2
    scatter(Q2(i,1),Q2(i,2),'r^'); hold on    
    scatter(permute(i).Q2(:,1),permute(i).Q2(:,2),'ro'); hold on
    centroidQ2=mean(permute(i).Q2);
    %draw a line joining a point (Q2) to the centroid 
    plot([Q2(i,1) centroidQ2(1)],[Q2(i,2) centroidQ2(2)],'k'); %plot a line joining centroid to actual
    hold on
    legend('Actual R2Y','Permuted R2Y', 'Actual Q2','Permuted Q2', 'Location','northwest')
end

end