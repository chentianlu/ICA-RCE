function hPopupmenuSelectCallback(obj, src, event)    
    obj.objController.selectData();
end