function hMenuitemCloseCallback(obj, src, event) 
    close all
    %note that the Constroller object will still remain in the workspace
end