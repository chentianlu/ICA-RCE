function drawLogisticRegression(obj, p) 
%%
%INPUT
%p: IxJ matrix, where I is number of classification variables, and J is number of corrected components
%%
dimY = size(p.Y,2); %classification variables
figure('Name','P value of OR: chi-square test of x and yfit','NumberTitle', 'off');
%%
for i=1:dimY %i is the index of the instructor (classification variable)
    subplot(dimY, 1, i);
    boxplot([p.pcrude(i,:)' p.padjusted(i,:)']);
    ylabel('p-values');
    %display the component name, in descending order
    str = {'crude','adjusted'};
    set(gca, 'XTickLabel',str, 'XTick',1:numel(str));
    drawnow;
end
end
