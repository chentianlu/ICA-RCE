function hBtnGrpPreprocessCallback(obj, src, event)
    preprocessmode = get(event.NewValue,'String');
    maxcomps = obj.objController.getMaxNumComponents();
    
    switch preprocessmode
        case 'ICA'
            if (maxcomps < 5)
                set (obj.hEditNumDCs, 'String', num2str(maxcomps));
            else
                set (obj.hEditNumDCs, 'String', num2str(5));
            end
        case 'EMD'
            if (maxcomps < 5)
                set (obj.hEditNumDCs, 'String', num2str(maxcomps));
            else
                set (obj.hEditNumDCs, 'String', num2str(5));
            end
        otherwise
            set (obj.hEditNumDCs, 'String', num2str(2));
    end
end

