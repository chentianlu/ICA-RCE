function drawLinePlot(obj, T, selectedDCs)
    %selectedDCs is a vector of indices for the decomposed components, e.g. [1,3,5]    
    maxDCs = min(size(T));
    if maxDCs > 10; 
        maxDCs = 10; %display up to 10 line plots
    end    
    selectedDCs = selectedDCs(find(selectedDCs<=maxDCs)); %make use of user selection, but only up to maxDCs
    
    %The code below uses "subplot"
    %As such, a floating figure window must be created as it is not possible to get
    %subplot to plot in the existing axes properly
    figure('Name','Components','NumberTitle', 'off');
    for i = 1:numel(selectedDCs)
        componentnumber = selectedDCs(i);
        subplot(numel(selectedDCs), 1, i);
        plot(T(:, componentnumber),'gs-','MarkerSize',3,'MarkerEdgeColor','b','MarkerFaceColor',[0.5,0.5,0.5]);
        xlabel(['T' num2str(componentnumber)]);
        drawnow;
    end
end  
