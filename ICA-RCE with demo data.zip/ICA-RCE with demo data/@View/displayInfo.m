function displayInfo(obj, con)
    str = [con.objModel.file ': ' num2str(con.objModel.ng) ' Classification Variables; ' num2str(con.objModel.nc) ' Confounding Factors; ' num2str(con.objModel.nm) ' Metabolites']; 
    set(obj.hLabelCenter,'String', str);
end