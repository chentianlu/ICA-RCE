function hBtnRecommendCallback(obj, src, event)   
    obj.objController.recommendComponents2Remove();    
    obj.displayStatus(['Recommend: ' ' OK']);
        
end 
