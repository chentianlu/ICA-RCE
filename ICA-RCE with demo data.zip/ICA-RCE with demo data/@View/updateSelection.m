function updateSelection(obj, nDCs, nCFs)
    %Decomposed Component Numbers on the "ICA Selection" Panel.    
    set(obj.hEditSelectDecomposedComponentNumbers, 'String', num2str(nDCs));
    %Instructor (CFs) on the "ICA Selection" Panel.    
    set(obj.hEditSelectConfoundingFactorNumbers, 'String', num2str(nCFs));
end

