function hMenuitemOpenCallback(obj, src, event) 
    [file, path] = uigetfile({'*.csv','Comma separated files (*csv)';'*xls;*xlsx','Excel files (*.xls,*.xlsx)';'*.*','All files (*.*)'},'File Selector');
    if ~isequal(file, 0)
        obj.objController.openFile(file, path);
        set(findall(obj.hPanelLeft, '-property', 'enable'), 'enable', 'on'); %enable left panel
        obj.displayStatus('Open File: OK');
    end
end
