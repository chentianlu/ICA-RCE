 function hMenuitemSaveCallback(obj, src, event)
    bool = obj.objController.saveData();
    if bool == false
        msgbox('There is no data to be saved.', 'modal');
    else
        obj.displayStatus('Mat file saved: OK');
    end        
 end