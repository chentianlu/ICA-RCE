function drawAUC(obj, p) 
%
%this function is used in two places: during evaluation and selection process.
%
%INPUT
%p: IxJ matrix, where I is number of confounding factors, and J is number of removed components/decomposed components 
%
dimX = size(p.X,2); %decomposed components
dimY = size(p.Y,2); %confounding factors

figure('Name','AUC','NumberTitle', 'off');
str=cell(1); %initalize an empty cell array to store component names

for i=1:dimY
    for j=1:dimX
        str{j}=['C' num2str(p.X(j))]; % concatenate the component name for bar display
    end
    subplot(dimY, 1, i);
    [pv, index] = sort(p.av(i,:),'descend');
    bar(pv);
    ylabel(['auc ' num2str(p.Y(i))]);
    %display the component name, in descending order
    str = str(index);
    set(gca, 'XTickLabel',str, 'XTick',1:numel(str));
    drawnow;
end
end
